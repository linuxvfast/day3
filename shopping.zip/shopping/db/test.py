import os,sys
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
from conf import setting
import datetime
filename = ["user_info", "shopping_info", 'balance_info']
fileback = ['user_info_bak', 'shopping_info_bak', 'balance_info_bak', 'user_info_new']
product_info = ['("Iphone", 8880)']
with open('%s/%s' % (setting.file_dir, filename[1]), 'r', encoding='utf-8') as rf, \
        open('%s/%s' % (setting.file_dir, fileback[1]), 'w', encoding='utf-8') as wf:
    tag = False
    data = 'user:' + 'test' + ' ' + str(datetime.datetime.now()).split()[0]
    for line in rf:
        if line.strip() == data:
            tag = True
            # wf.write(line)
            product_info.insert(0,line)
            continue
        if not tag:
            wf.write(line)
        if tag and not line.startswith('user'):
            # wf.write(line)
            product_info.append(line)
        if tag and line.startswith('user'):
            tag = False
            wf.write(line)
    for i in product_info:
        wf.write(i)