__author__ = 'progress'

import os,sys,json,datetime
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# print(base_dir)
from conf import setting

def register(filename):
    '''
    检查数据文件是否存在,以及注册用户
    :return:
    '''
    # 检查文件
    # file_name = ["user_info", "shopping_info", 'balance_info']
    file_name = filename
    for file in file_name:
        if not os.path.isfile('%s/%s'%(setting.file_dir,file)):
            with open('%s/%s'%(setting.file_dir,file), "w", encoding="utf-8") as f:
                f.write(" ")

    # 注册用户
    with open('%s/%s'%(setting.file_dir,file_name[0]),'r',encoding='utf-8') as user_info, \
            open('%s/%s'%(setting.file_dir,file_name[0]), 'a', encoding='utf-8') as write_user:
        check_user = False
        while not check_user:
            user = input('请输入用户名:')
            user_info.seek(0)   #每次输入重复的名字都提示存在
            user_check = []
            for user_list in user_info:
                check_list = user_list.strip().split()
                if check_list != []:
                    user_check.append(check_list[0])
            # print(user_check)
            if user in user_check:
                print('用户已经存在！')
                check_user = False
            else:
                check_user = True
                break
        password = input('请输入密码:')
        write_user.writelines('%s %s %s\n'%(user,password,'F'))
    print('注册完成请登录')

def login(filename):
    '''
    登录验证
    :return:
    '''
    while True:
        username = input('请输入用户名:')
        password = input('请输入密码:')
        with open('%s/%s' %(setting.file_dir,filename[0]), 'r', encoding='utf-8') as user_check:
            for line in user_check:
                line_list = line.strip().split()
                # print(line_list)
                if username == line_list[0] and password == line_list[1]:
                    print("\033[41;1m登陆成功\033[0m")
                    return [True, username]
            else:
                print("\033[41;1m用户名或密码无效，请重新登陆\033[0m")
                return [False,username]
                break

def add_money(args,filename):
    '''
    第一次登录的用户充值金额
    :return:
    '''
    while True:
        add_balance = input('请输入充值的金额:')
        if add_balance.isdigit() and int(add_balance) > 0:
            str_balance = args + ' ' + str(add_balance)
            with open('%s/%s'%(setting.file_dir,filename[2]),'a',encoding='utf-8') as balance_info:
                balance_info.write(str_balance)
                break
        else:
            print('输入错误，请重新输入')
            continue

def history_shopping(exp,filname,user_time):
    '''购物记录'''
    result_info = []
    data = "user:%s %s" % (exp,user_time)
    with open('%s/%s'%(setting.file_dir,filname[1]),'r',encoding='utf-8') as r_shop:
        tags = False
        for line in r_shop:
            if line.strip() == data:
                tags = True
                continue
            if tags and line.startswith('user'):
                break
            if tags and line:
                result_info.append(line.strip())
        print('当前时间的购物记录'.center(20,'*'))
        for line in result_info:
            print(line)
        print('到底啦'.center(20,'*'))

def get_balance(username,filename):
    '''获取余额'''
    with open('%s/%s'%(setting.file_dir,filename[2]), 'r', encoding='utf-8') as store_file:
        for line in store_file:
            line = line.strip().split()
            if line[0]  == username:
                print('当前的余额为%s' % line[1])
                return line[1]

        # balance = store_file.readline()
        # if balance.isdigit():
        #     print('当前的余额为%s' % balance)
        #     return balance
        # else:
        #     print('当前的余额为0')
        #     return balance

product_list = [
    ("Iphone", 8880),
    ("Huawei", 4888),
    ("Xiaomi", 2588),
    ("Nokia", 3800),
    ("Lenovo", 1588),
    ("Vivo", 2148),
    ("Oppo", 2488)
]

def run():
    filename = ["user_info", "shopping_info", 'balance_info']
    fileback = ['user_info_bak','shopping_info_bak','balance_info_bak','user_info_new']
    judge = False
    while not judge:
        print('欢迎您登录购物商城'.center(50, '*'))
        print(
            '''
            登录请选择(L)
            注册请选择(R)
            退出请选择(q)
            ''')
        choose = input('\033[41m 请选择>>>: \033[0m')
        if choose == 'q':break
        if choose == 'R':
            register(filename)
        if choose == 'L':
            count = ''  #判断是否充值
            res = login(filename)   #用户登录成功的判断 True为成功 False为失败
            # print('from in run %s'%res)
            if res[0] == False:continue

            #判断用户是否需要充值
            if res[0] == True:
                with open('%s/%s'%(setting.file_dir,filename[0]),'r',encoding='utf-8') as fh:
                    for line in fh:
                        line = line.strip().split()
                        # print('line0',line[0])
                        # print('line1', line[1])
                        # print('line2',line[2])
                        if line[0] == res[1]:
                            count = line[2]
            # print('count',count)
            if count == 'F' and res[0] == True:
                add_money(res[1],filename)
                with open('%s/%s'%(setting.file_dir,filename[0]),'r',encoding='utf-8') as f,\
                    open('%s/%s' % (setting.file_dir,fileback[0]), 'w', encoding='utf-8') as wh:
                    char = ''
                    for line in f:
                        line = line.strip().split()
                        print(line)
                        if line[0] == res[1]:
                            line[2] = 'T'
                            char = line[0]+' '+line[1]+' '+line[2]
                            wh.write(char+'\n')
                        else:
                            char = line[0]+' '+line[1]+' '+line[2]
                            wh.write(char+'\n')
                os.remove('%s/%s'%(setting.file_dir,filename[0]))
                os.rename('%s/%s'%(setting.file_dir,fileback[0]),'%s/%s'%(setting.file_dir,filename[0]))
            product_info = []
            shop_info = []
            while True:
                for index, line in enumerate(product_list,start=1):
                    print(index, line)
                print('开始购物直接输入序列号,查看消费记录(c),退出(q)')
                get_balance(res[1],filename)
                choice = input('\033[41;1m请输入>>>\033[0m')
                if len(choice) == 0:continue
                elif choice == 'q':
                    # with open('%s/%s' % (setting.file_dir, filename[1]), 'a', encoding='utf-8') as rf:
                    #     rf.write('user:'+res[1] + ' ' + str(datetime.datetime.now()).split()[0] +'\n')
                    #     for shop in product_info:
                    #         rf.write(shop + '\n')
                    with open('%s/%s' % (setting.file_dir, filename[1]), 'r', encoding='utf-8') as rf, \
                            open('%s/%s' % (setting.file_dir, fileback[1]), 'w', encoding='utf-8') as wf:
                        tag = False
                        data = 'user:' + 'test' + ' ' + str(datetime.datetime.now()).split()[0]
                        for line in rf:
                            if line.strip() == data:
                                tag = True
                                # wf.write(line)
                                product_info.insert(0, line)
                                continue
                            if not tag:
                                wf.write(line)
                            if tag and not line.startswith('user'):
                                # wf.write(line)
                                product_info.append(line)
                            if tag and line.startswith('user'):
                                tag = False
                                wf.write(line)
                        for i in product_info:
                            wf.write(i)




                    get_balance(res[1], filename)
                    print('购买的商品如下'.center(50, '*'))
                    for shop in shop_info:
                        print(shop)
                    sys.exit()
                elif choice == 'c':
                    user_time = input('请输入查询时间:(2018-03-12)')
                    history_shopping(res[1],filename,user_time)
                else:
                    if int(choice) in range(1,len(product_list)+1):
                        shop_item = product_list[int(choice) - 1]
                        # print('shop_item',shop_item)
                        rest_balance = get_balance(res[1],filename)
                        # print('rest_balance',rest_balance)
                        rest_balance = int(rest_balance)
                        if shop_item[1] > rest_balance:
                            print('余额不足')
                        else:
                            rest_balance -= shop_item[1]
                            product_info.append(str(shop_item)+'\n')
                            shop_info.append(str(shop_item) + '\n')
                        with open('%s/%s'%(setting.file_dir,filename[2]), 'r', encoding='utf-8')as r_file,\
                                open('%s/%s'%(setting.file_dir,fileback[2]), 'w', encoding='utf-8')as w_file:
                            char = ''
                            new_list = []
                            for line in r_file:
                                line = line.strip().split()
                                # print(line)
                                if res[1] == line[0]:
                                    line[1] = rest_balance
                                    char = line[0] + ' ' + str(line[1])
                                    new_list.append(char)
                                else:
                                    char = line[0] + ' ' + str(line[1])
                                    new_list.append(char)
                            # print('new_list',new_list)
                            for i in new_list:
                                w_file.write(i+'\n')

                        os.remove('%s/%s'%(setting.file_dir,filename[2]))
                        os.rename('%s/%s'%(setting.file_dir,fileback[2]),'%s/%s'%(setting.file_dir,filename[2]))
                        os.remove('%s/%s' % (setting.file_dir, filename[1]))
                        os.rename('%s/%s' % (setting.file_dir, fileback[1]), '%s/%s' % (setting.file_dir, filename[1]))









