__author__ = 'progress'

import os
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
file_dir = '%s/db'%base_dir